﻿using RestaurantMvc.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RestaurantMvc.ViewModel
{
    public class FoodItemInfo
    {
        public IEnumerable<int> foodids { get; set; }
        public FoodSell foodie { get; set; }
    }
}
