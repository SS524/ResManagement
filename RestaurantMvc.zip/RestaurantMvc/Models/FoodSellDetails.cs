﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RestaurantMvc.Models
{
    public class FoodSellDetails
    {
        public int FoodFetchId { get; set; }
    }
}
