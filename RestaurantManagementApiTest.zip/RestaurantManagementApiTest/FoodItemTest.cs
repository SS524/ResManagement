using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Moq;
using NUnit.Framework;
using RestaurantManagement.Controllers;
using RestaurantManagement.Models;
using RestaurantManagement.Repository;
using System.Collections.Generic;
using System.Linq;

namespace RestaurantManagementApiTest
{
    public class FoodItemTest
    {
        RestaurantContext db;
        [SetUp]
        
        
        public void Setup()
        {


            var food = new List<FoodItem>
            {
                new FoodItem{FoodId = 100, FoodName = "Dummy", FoodType="Dummy1", FoodPrice=100,IsAvailable="Dummy",HomeDelivery="Dummy"},
                new FoodItem{FoodId = 101, FoodName ="Dummy", FoodType="Dummy2", FoodPrice=100,IsAvailable="Dummy",HomeDelivery="Dummy"},
                new FoodItem{FoodId = 102, FoodName = "Dummy", FoodType="Dummy3", FoodPrice=100,IsAvailable="Dummy ",HomeDelivery="Dummy"},
                new FoodItem{FoodId = 103, FoodName = "Dummy",FoodType="Dummy4", FoodPrice=100,IsAvailable="Dummy ",HomeDelivery="Dummy"}
            };
            var loandata = food.AsQueryable();
            var mockSet = new Mock<DbSet<FoodItem>>();
            mockSet.As<IQueryable<FoodItem>>().Setup(m => m.Provider).Returns(loandata.Provider);
            mockSet.As<IQueryable<FoodItem>>().Setup(m => m.Expression).Returns(loandata.Expression);
            mockSet.As<IQueryable<FoodItem>>().Setup(m => m.ElementType).Returns(loandata.ElementType);
            mockSet.As<IQueryable<FoodItem>>().Setup(m => m.GetEnumerator()).Returns(loandata.GetEnumerator());
          
               var mockContext = new Mock<RestaurantContext>();
               mockContext.Setup(c => c.FoodItems).Returns(mockSet.Object);
           
            db = mockContext.Object;
        }

        [Test]
        public void GetFoodTest()
        {
            var repo = new Mock<FoodItemRepo>(db);
            FoodItemController obj = new FoodItemController(repo.Object);
            
            var data = obj.Get();
            var okresult = data as OkObjectResult;
            
            Assert.AreEqual(200,okresult.StatusCode);
            
        }
        [Test]
        public void FoodPutTestPass()
        {
            var repo = new Mock<FoodItemRepo>(db);
            FoodItemController obj = new FoodItemController(repo.Object);
            FoodItem food = new FoodItem { FoodId = 100, FoodName = "Dummy2", FoodType = "Dummy4", FoodPrice = 100, IsAvailable = "Dummy ", HomeDelivery = "Dummy" };
            var data = obj.Put(100,food);
           

            Assert.AreEqual("Successfully Updated", data);
         
        }
        [Test]
        public void FoodPutTestFail()
        {
            var repo = new Mock<FoodItemRepo>(db);
            FoodItemController obj = new FoodItemController(repo.Object);
            FoodItem food = new FoodItem { FoodId = 10, FoodName = "Dummy2", FoodType = "Dummy4", FoodPrice = 100, IsAvailable = "Dummy ", HomeDelivery = "Dummy" };
            var data = obj.Put(10, food);


            Assert.AreEqual("Id does not exist", data);

        }
      /*  [Test]
        public void FoodPostTest()
        {
            var repo = new Mock<FoodItemRepo>(db);
            FoodItemController obj = new FoodItemController(repo.Object);
            FoodItem food = new FoodItem { FoodId = 300, FoodName = "Dummy", FoodType = "Dummy1", FoodPrice = 100, IsAvailable = "Dummy", HomeDelivery = "Dummy" };
            var data = obj.Post(food);
            var okresult = data as OkObjectResult;
            Assert.AreEqual(200, okresult.StatusCode);
            
        }*/
        [Test]
        public void GetByIdFoodTestPass()
        {

            var repo = new Mock<FoodItemRepo>(db);
            FoodItemController obj = new FoodItemController(repo.Object);
            var data = obj.Get(103);
             var okresult = data as ObjectResult;

             Assert.AreEqual(200, okresult.StatusCode);
        }

        [Test]
        public void GetByIdFoodTestPass1()
        {

            var repo = new Mock<FoodItemRepo>(db);
            FoodItemController obj = new FoodItemController(repo.Object);
            var data = obj.Get(102);
            var okresult = data as ObjectResult;

            Assert.AreEqual(200, okresult.StatusCode);
        }

        [Test]
        public void GetByIdFoodTestFail()
        {

            var repo = new Mock<FoodItemRepo>(db);
            FoodItemController obj = new FoodItemController(repo.Object);
            var data = obj.Get(10);
            var okresult = data as ObjectResult;

            Assert.AreEqual(400, okresult.StatusCode);
        }

        [Test]
        public void GetByIdFoodTestFail1()
        {

            var repo = new Mock<FoodItemRepo>(db);
            FoodItemController obj = new FoodItemController(repo.Object);
            var data = obj.Get(20);
            var okresult = data as ObjectResult;

            Assert.AreEqual(400, okresult.StatusCode);
        }

        /* [Test]
         public void DeleteFoodTestPass()
         {

             var repo = new Mock<FoodItemRepo>(db);
             FoodItemController obj = new FoodItemController(repo.Object);
             var data = obj.Delete(101);


             Assert.AreEqual("Successfully Deleted",data);
         }*/

    }
}