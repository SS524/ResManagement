﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Moq;
using NUnit.Framework;
using RestaurantManagement.Controllers;
using RestaurantManagement.Models;
using RestaurantManagement.Repository;
using System;
using System.Collections.Generic;
using System.Linq;

namespace RestaurantManagementApiTest
{
    public class FoodSellTest
    {
        RestaurantContext db;
        [SetUp]


        public void Setup()
        {


            var foodsell = new List<FoodSell>
            {
                new FoodSell{SellId = 100, FoodItemId = 50, WhoOrdered="Dummy1", Quantity=100},
                new FoodSell {SellId = 101, FoodItemId = 50, WhoOrdered="Dummy1", Quantity=100}

            };
            var loandata = foodsell.AsQueryable();
            var mockSet = new Mock<DbSet<FoodSell>>();
            mockSet.As<IQueryable<FoodSell>>().Setup(m => m.Provider).Returns(loandata.Provider);
            mockSet.As<IQueryable<FoodSell>>().Setup(m => m.Expression).Returns(loandata.Expression);
            mockSet.As<IQueryable<FoodSell>>().Setup(m => m.ElementType).Returns(loandata.ElementType);
            mockSet.As<IQueryable<FoodSell>>().Setup(m => m.GetEnumerator()).Returns(loandata.GetEnumerator());

            var mockContext = new Mock<RestaurantContext>();
            mockContext.Setup(c => c.FoodSells).Returns(mockSet.Object);

            db = mockContext.Object;
        }

        [Test]
        public void GetFoodTest()
        {
            var repo = new Mock<FoodSellRepo>(db);
            FoodSellController obj = new FoodSellController(repo.Object);

            var data = obj.Get();
            var okresult = data as OkObjectResult;

            Assert.AreEqual(200, okresult.StatusCode);

        }
      
      /*  [Test]
        public void FoodPostTest()
        {
            var repo = new Mock<FoodSellRepo>(db);
            FoodSellController obj = new FoodSellController(repo.Object);
            FoodSell food = new FoodSell { SellId = 101, FoodItemId = 50, WhoOrdered = "Dummy1", Quantity = 100 };
            var data = obj.Post(food);
            Assert.AreEqual("Success", data);

        }*/
        [Test]
        public void GetByIdFoodTestPass()
        {

            var repo = new Mock<FoodSellRepo>(db);
            FoodSellController obj = new FoodSellController(repo.Object);
            var data = obj.Get(50);
            var okresult = data as ObjectResult;

            Assert.AreEqual(200, okresult.StatusCode);
        }

        [Test]
        public void GetByIdFoodTestFail()
        {

            var repo = new Mock<FoodSellRepo>(db);
            FoodSellController obj = new FoodSellController(repo.Object);
            var data = obj.Get(8);
            var okresult = data as ObjectResult;

            Assert.AreEqual(400, okresult.StatusCode);
        }

        /* [Test]
         public void DeleteFoodTestPass()
         {

             var repo = new Mock<FoodItemRepo>(db);
             FoodItemController obj = new FoodItemController(repo.Object);
             var data = obj.Delete(101);


             Assert.AreEqual("Successfully Deleted", data);
         }*/

    }
}
